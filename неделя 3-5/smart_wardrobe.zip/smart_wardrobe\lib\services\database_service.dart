import 'package:sqflite/sqflite.dart';
import '../models/clothing_item.dart';
import '../models/outfit.dart';
import 'app_paths.dart';

/// Слой доступа к SQLite. Схема совпадает с папкой sqlite/.
class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  static const _userId = 'local-user';

  Database? _db;
  Database get db => _db!;

  Map<String, int> _catIds = {};
  Map<int, String> _catRev = {};
  Map<String, int> _colorIds = {};
  Map<int, String> _colorRev = {};
  Map<String, int> _seasonIds = {};
  Map<int, String> _seasonRev = {};

  Future<void> init() async {
    final path = '${await getDatabasesPath()}/smart_wardrobe.db';
    _db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createSchema,
    );
    await _loadRefs();
  }

  Future<void> _createSchema(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT,
        birth_date TEXT,
        gender TEXT,
        city TEXT,
        style TEXT,
        size TEXT,
        avatar_path TEXT,
        password_hash TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    ''');

    await db.execute('''
      CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        sort INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE colors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        hex TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE seasons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
      )
    ''');

    await db.execute('''
      CREATE TABLE clothing_items (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        category_id INTEGER NOT NULL,
        color_id INTEGER,
        name TEXT NOT NULL,
        description TEXT,
        size TEXT,
        image_path TEXT,
        price REAL,
        currency TEXT NOT NULL DEFAULT 'RUB',
        last_worn TEXT,
        wear_count INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
        FOREIGN KEY (color_id) REFERENCES colors(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE item_seasons (
        item_id TEXT NOT NULL,
        season_id INTEGER NOT NULL,
        PRIMARY KEY (item_id, season_id),
        FOREIGN KEY (item_id) REFERENCES clothing_items(id) ON DELETE CASCADE,
        FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE outfits (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        cover_image TEXT,
        last_worn TEXT,
        wear_count INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE outfit_items (
        outfit_id TEXT NOT NULL,
        item_id TEXT NOT NULL,
        position INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (outfit_id, item_id),
        FOREIGN KEY (outfit_id) REFERENCES outfits(id) ON DELETE CASCADE,
        FOREIGN KEY (item_id) REFERENCES clothing_items(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE wear_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        outfit_id TEXT,
        worn_at TEXT NOT NULL,
        note TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (outfit_id) REFERENCES outfits(id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE wear_log_items (
        wear_id INTEGER NOT NULL,
        item_id TEXT NOT NULL,
        PRIMARY KEY (wear_id, item_id),
        FOREIGN KEY (wear_id) REFERENCES wear_log(id) ON DELETE CASCADE,
        FOREIGN KEY (item_id) REFERENCES clothing_items(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('CREATE INDEX idx_items_user ON clothing_items(user_id)');
    await db.execute('CREATE INDEX idx_items_category ON clothing_items(category_id)');
    await db.execute('CREATE INDEX idx_items_last_worn ON clothing_items(last_worn)');
    await db.execute('CREATE INDEX idx_outfits_user ON outfits(user_id)');
    await db.execute('CREATE INDEX idx_outfit_items_item ON outfit_items(item_id)');
    await db.execute('CREATE INDEX idx_wearlog_user_date ON wear_log(user_id, worn_at)');

    // ===== seed =====
    for (final c in const [
      ['Верх', 1],
      ['Низ', 2],
      ['Обувь', 3],
      ['Верхняя одежда', 4],
      ['Аксессуары', 5],
    ]) {
      await db.insert('categories', {'name': c[0], 'sort': c[1]});
    }
    for (final s in const ['Лето', 'Весна', 'Осень', 'Зима']) {
      await db.insert('seasons', {'name': s});
    }
    for (final c in const [
      ['Белый', '#FFFFFF'],
      ['Чёрный', '#191720'],
      ['Синий', '#5B4BFF'],
      ['Серый', '#9AA0A6'],
      ['Красный', '#F0564A'],
      ['Зелёный', '#22A06B'],
      ['Бежевый', '#D9C4AE'],
    ]) {
      await db.insert('colors', {'name': c[0], 'hex': c[1]});
    }
    await db.insert('users', {
      'id': _userId,
      'name': 'Пользователь',
      'email': 'user@local',
    });
  }

  Future<void> _loadRefs() async {
    _catIds = {};
    _catRev = {};
    for (final r in await db.query('categories')) {
      final id = r['id'] as int;
      final name = r['name'] as String;
      _catIds[name] = id;
      _catRev[id] = name;
    }
    _colorIds = {};
    _colorRev = {};
    for (final r in await db.query('colors')) {
      final id = r['id'] as int;
      final name = r['name'] as String;
      _colorIds[name] = id;
      _colorRev[id] = name;
    }
    _seasonIds = {};
    _seasonRev = {};
    for (final r in await db.query('seasons')) {
      final id = r['id'] as int;
      final name = r['name'] as String;
      _seasonIds[name] = id;
      _seasonRev[id] = name;
    }
  }

  // ==================== ВЕЩИ ====================

  Future<List<ClothingItem>> getItems() async {
    final rows = await db.query('clothing_items');
    final result = <ClothingItem>[];
    for (final r in rows) {
      final id = r['id'] as String;
      final seasonRows =
          await db.query('item_seasons', where: 'item_id = ?', whereArgs: [id]);
      final seasons = seasonRows
          .map((s) => _seasonRev[s['season_id'] as int])
          .whereType<String>()
          .toList();
      final img = r['image_path'] as String?;
      result.add(ClothingItem(
        id: id,
        name: r['name'] as String,
        description: (r['description'] as String?) ?? '',
        category: _catRev[r['category_id'] as int] ?? '',
        color: _colorRev[r['color_id'] as int?] ?? '',
        season: seasons,
        imagePath: (img == null || img.isEmpty)
            ? null
            : AppPaths.instance.toAbsolute(img),
        price: (r['price'] as num?)?.toDouble(),
        lastWorn: r['last_worn'] == null
            ? null
            : DateTime.tryParse(r['last_worn'] as String),
        wearCount: (r['wear_count'] as int?) ?? 0,
      ));
    }
    return result;
  }

  Future<void> insertItem(ClothingItem item) async {
    await db.insert('clothing_items', _itemToRow(item),
        conflictAlgorithm: ConflictAlgorithm.replace);
    await _replaceSeasons(item.id, item.season);
  }

  Future<void> updateItem(ClothingItem item) async {
    await db.update('clothing_items', _itemToRow(item),
        where: 'id = ?', whereArgs: [item.id]);
    await _replaceSeasons(item.id, item.season);
  }

  Future<void> deleteItem(String id) async {
    await db.delete('clothing_items', where: 'id = ?', whereArgs: [id]);
    // item_seasons, outfit_items, wear_log_items удалятся каскадом
  }

  Future<void> markWorn(List<String> ids, DateTime when) async {
    if (ids.isEmpty) return;
    final iso = when.toIso8601String();
    final batch = db.batch();
    for (final id in ids) {
      batch.rawUpdate(
        'UPDATE clothing_items SET last_worn = ?, wear_count = wear_count + 1 WHERE id = ?',
        [iso, id],
      );
    }
    await batch.commit(noResult: true);
  }

  Map<String, Object?> _itemToRow(ClothingItem it) {
    final img = it.imagePath;
    return {
      'id': it.id,
      'user_id': _userId,
      'category_id': _catIds[it.category] ?? _catIds.values.first,
      'color_id': _colorIds[it.color],
      'name': it.name,
      'description': it.description,
      'image_path': (img == null || img.isEmpty)
          ? null
          : AppPaths.instance.toRelative(img),
      'price': it.price,
      'currency': 'RUB',
      'last_worn': it.lastWorn?.toIso8601String(),
      'wear_count': it.wearCount,
      'updated_at': DateTime.now().toIso8601String(),
    };
  }

  Future<void> _replaceSeasons(String itemId, List<String> seasons) async {
    await db.delete('item_seasons', where: 'item_id = ?', whereArgs: [itemId]);
    for (final s in seasons) {
      final sid = _seasonIds[s];
      if (sid != null) {
        await db.insert(
          'item_seasons',
          {'item_id': itemId, 'season_id': sid},
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );
      }
    }
  }

  // ==================== ОБРАЗЫ ====================

  Future<List<Outfit>> getOutfits() async {
    final rows = await db.query('outfits');
    final result = <Outfit>[];
    for (final r in rows) {
      final id = r['id'] as String;
      final itemRows = await db.query(
        'outfit_items',
        where: 'outfit_id = ?',
        whereArgs: [id],
        orderBy: 'position ASC',
      );
      result.add(Outfit(
        id: id,
        name: r['name'] as String,
        itemIds: itemRows.map((x) => x['item_id'] as String).toList(),
        lastWorn: r['last_worn'] == null
            ? null
            : DateTime.tryParse(r['last_worn'] as String),
      ));
    }
    return result;
  }

  Future<void> insertOutfit(Outfit o) async {
    await db.insert(
      'outfits',
      {
        'id': o.id,
        'user_id': _userId,
        'name': o.name,
        'last_worn': o.lastWorn?.toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    await _replaceOutfitItems(o.id, o.itemIds);
  }

  Future<void> updateOutfit(Outfit o) async {
    await db.update(
      'outfits',
      {
        'name': o.name,
        'last_worn': o.lastWorn?.toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [o.id],
    );
    await _replaceOutfitItems(o.id, o.itemIds);
  }

  Future<void> deleteOutfit(String id) async {
    await db.delete('outfits', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> _replaceOutfitItems(String outfitId, List<String> itemIds) async {
    await db.delete('outfit_items', where: 'outfit_id = ?', whereArgs: [outfitId]);
    for (var i = 0; i < itemIds.length; i++) {
      await db.insert(
        'outfit_items',
        {'outfit_id': outfitId, 'item_id': itemIds[i], 'position': i},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  /// Записать «надевание образа» в журнал и обновить кэш образа.
  /// Вещи обновляются отдельно через markWorn.
  Future<void> recordWearOutfit(Outfit o, DateTime when) async {
    final iso = when.toIso8601String();
    final wearId = await db.insert('wear_log', {
      'user_id': _userId,
      'outfit_id': o.id,
      'worn_at': iso,
    });
    for (final itemId in o.itemIds) {
      await db.insert(
        'wear_log_items',
        {'wear_id': wearId, 'item_id': itemId},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await db.rawUpdate(
      'UPDATE outfits SET last_worn = ?, wear_count = wear_count + 1 WHERE id = ?',
      [iso, o.id],
    );
  }
}
