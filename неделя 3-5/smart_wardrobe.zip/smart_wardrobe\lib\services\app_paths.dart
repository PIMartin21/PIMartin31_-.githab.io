import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Единые пути приложения и преобразование относительный ↔ абсолютный.
///
/// В памяти модели хранят АБСОЛЮТНЫЙ путь (удобно для Image.file),
/// а в БД пишется ОТНОСИТЕЛЬНЫЙ (устойчив к переустановке).
class AppPaths {
  AppPaths._();
  static final AppPaths instance = AppPaths._();

  late String documentsDir;

  Future<void> init() async {
    documentsDir = (await getApplicationDocumentsDirectory()).path;
  }

  Directory get imagesDir => Directory(p.join(documentsDir, 'images'));

  String toAbsolute(String? relOrAbs) {
    if (relOrAbs == null || relOrAbs.isEmpty) return '';
    if (relOrAbs.startsWith('/') || relOrAbs.contains(':')) return relOrAbs;
    return p.join(documentsDir, relOrAbs);
  }

  String toRelative(String? abs) {
    if (abs == null || abs.isEmpty) return '';
    if (abs.startsWith(documentsDir)) {
      return abs.substring(documentsDir.length + 1).replaceAll('\\', '/');
    }
    return abs.replaceAll('\\', '/');
  }
}
