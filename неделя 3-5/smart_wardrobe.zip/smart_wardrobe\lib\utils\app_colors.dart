import 'package:flutter/material.dart';

/// Сопоставляет название цвета вещи с цветом для отображения на экране.
Color colorForName(String name) {
  switch (name) {
    case 'Белый':
      return Colors.white;
    case 'Чёрный':
      return const Color(0xFF191720);
    case 'Синий':
      return const Color(0xFF5B4BFF);
    case 'Серый':
      return const Color(0xFF9AA0A6);
    case 'Красный':
      return const Color(0xFFF0564A);
    case 'Зелёный':
      return const Color(0xFF22A06B);
    case 'Бежевый':
      return const Color(0xFFD9C4AE);
    default:
      return const Color(0xFF8A8694);
  }
}
