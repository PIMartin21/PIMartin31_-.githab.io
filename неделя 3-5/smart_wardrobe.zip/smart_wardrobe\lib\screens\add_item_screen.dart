import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/clothing_item.dart';
import '../services/wardrobe_store.dart';
import '../services/image_service.dart';
import '../utils/app_colors.dart';

class AddItemScreen extends StatefulWidget {
  /// Если передан — экран работает в режиме редактирования.
  final ClothingItem? initialItem;
  const AddItemScreen({super.key, this.initialItem});

  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  final _nameController = TextEditingController();
  final _descController = TextEditingController();
  final _priceController = TextEditingController();
  String _category = 'Верх';
  String _color = 'Белый';
  final Set<String> _seasons = {'Лето'};
  String? _imagePath;

  bool get _isEditing => widget.initialItem != null;

  static const _categories = [
    'Верх',
    'Низ',
    'Обувь',
    'Верхняя одежда',
    'Аксессуары',
  ];
  static const _colors = [
    'Белый',
    'Чёрный',
    'Синий',
    'Серый',
    'Красный',
    'Зелёный',
    'Бежевый',
  ];
  static const _allSeasons = ['Лето', 'Весна', 'Осень', 'Зима'];

  @override
  void initState() {
    super.initState();
    final item = widget.initialItem;
    if (item != null) {
      _nameController.text = item.name;
      _descController.text = item.description;
      _category = item.category;
      _color = item.color;
      _seasons
        ..clear()
        ..addAll(item.season);
      _imagePath = item.imagePath;
      _priceController.text = item.price == null
          ? ''
          : (item.price! % 1 == 0
              ? item.price!.toStringAsFixed(0)
              : item.price!.toString());
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Введите название вещи')),
      );
      return;
    }
    final priceText = _priceController.text
        .trim()
        .replaceAll(RegExp(r'[^\d.,]'), '')
        .replaceAll(',', '.');
    final double? price = priceText.isEmpty ? null : double.tryParse(priceText);
    final item = ClothingItem(
      id: widget.initialItem?.id ??
          DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      description: _descController.text.trim(),
      category: _category,
      color: _color,
      season: _seasons.toList(),
      imagePath: _imagePath,
      price: price,
    );
    if (_isEditing) {
      WardrobeStore.instance.update(item);
    } else {
      WardrobeStore.instance.add(item);
    }
    Navigator.pop(context);
  }

  void _showPicker() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Сделать фото'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Выбрать из галереи'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            if (_imagePath != null)
              ListTile(
                leading:
                    const Icon(Icons.delete_outline, color: Color(0xFFF0564A)),
                title: const Text('Удалить фото',
                    style: TextStyle(color: Color(0xFFF0564A))),
                onTap: () {
                  Navigator.pop(context);
                  final old = _imagePath;
                  setState(() => _imagePath = null);
                  if (old != null) ImageService.instance.deleteImage(old);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 80,
        maxWidth: 1024,
      );
      if (picked == null) return;
      // Копируем в постоянную папку приложения, получаем абсолютный путь.
      final newPath = await ImageService.instance.saveImage(picked);
      final oldPath = _imagePath;
      if (!mounted) return;
      setState(() => _imagePath = newPath);
      // Старое фото (если заменяем) удаляем.
      if (oldPath != null && oldPath != newPath) {
        await ImageService.instance.deleteImage(oldPath);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не удалось получить фото: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAF8),
        title: Text(
          _isEditing ? 'Редактировать вещь' : 'Новая вещь',
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          const _FieldLabel('Фото вещи'),
          GestureDetector(
            onTap: _showPicker,
            child: Container(
              height: 180,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFFECE9F2),
                  width: 2,
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: _imagePath == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.add_a_photo_outlined,
                            size: 34, color: Color(0xFF5B4BFF)),
                        SizedBox(height: 8),
                        Text('Добавить фото',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF5B4BFF))),
                        SizedBox(height: 2),
                        Text('камера или галерея',
                            style: TextStyle(
                                fontSize: 11, color: Color(0xFF8A8694))),
                      ],
                    )
                  : Image.file(
                      File(_imagePath!),
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
            ),
          ),
          if (_imagePath != null)
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: _showPicker,
                icon: const Icon(Icons.edit, size: 16),
                label: const Text('Перефотографировать'),
              ),
            ),
          const SizedBox(height: 12),
          const _FieldLabel('Описание вещи'),
          TextField(
            controller: _descController,
            maxLines: 3,
            decoration:
                _inputDecoration('Например: хлопок, оверсайз, круглый вырез'),
          ),
          const SizedBox(height: 16),
          const _FieldLabel('Название'),
          TextField(
            controller: _nameController,
            decoration: _inputDecoration('Например: Белая футболка'),
          ),
          const SizedBox(height: 16),
          const _FieldLabel('Стоимость'),
          TextField(
            controller: _priceController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration:
                _inputDecoration('Например: 1500').copyWith(suffixText: '₽'),
          ),
          const SizedBox(height: 16),
          const _FieldLabel('Категория'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final c in _categories)
                _ChoiceChip(
                  label: c,
                  selected: _category == c,
                  onTap: () => setState(() => _category = c),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const _FieldLabel('Цвет'),
          Wrap(
            spacing: 14,
            runSpacing: 12,
            children: [
              for (final c in _colors)
                _ColorDot(
                  name: c,
                  selected: _color == c,
                  onTap: () => setState(() => _color = c),
                ),
            ],
          ),
          const SizedBox(height: 16),
          const _FieldLabel('Сезон'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final s in _allSeasons)
                _ChoiceChip(
                  label: s,
                  selected: _seasons.contains(s),
                  onTap: () => setState(() {
                    if (_seasons.contains(s)) {
                      _seasons.remove(s);
                    } else {
                      _seasons.add(s);
                    }
                  }),
                ),
            ],
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: _save,
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF5B4BFF),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            child: Text(
              _isEditing ? 'Сохранить изменения' : 'Добавить вещь',
              style:
                  const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF8A8694)),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFECE9F2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFECE9F2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFF5B4BFF)),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Color(0xFF8A8694),
        ),
      ),
    );
  }
}

class _ChoiceChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _ChoiceChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF191720) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? const Color(0xFF191720) : const Color(0xFFECE9F2),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
            color: selected ? Colors.white : const Color(0xFF8A8694),
          ),
        ),
      ),
    );
  }
}

class _ColorDot extends StatelessWidget {
  final String name;
  final bool selected;
  final VoidCallback onTap;
  const _ColorDot({
    required this.name,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: colorForName(name),
              shape: BoxShape.circle,
              border: Border.all(
                color: selected
                    ? const Color(0xFF5B4BFF)
                    : const Color(0xFFECE9F2),
                width: selected ? 3 : 1,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(name,
              style: const TextStyle(fontSize: 10, color: Color(0xFF8A8694))),
        ],
      ),
    );
  }
}
