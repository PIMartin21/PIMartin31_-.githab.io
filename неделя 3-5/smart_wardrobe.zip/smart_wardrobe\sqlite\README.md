# SmartWardrobe — архитектура базы данных (SQLite)

Папка содержит схему базы данных приложения-гардероба.

## Файлы

| Файл | Назначение |
|---|---|
| `schema.sql` | Полный DDL: таблицы, связи, ограничения, индексы |
| `seed.sql` | Начальные данные справочников (категории, цвета, сезоны) |
| `database.db` | Готовая база SQLite с применённой схемой (если создана) |
| `README.md` | Это описание архитектуры |

## Как применить схему

### Вариант 1 — через `sqlite3` (командная строка)
```
sqlite3 database.db < schema.sql
sqlite3 database.db < seed.sql
```

### Вариант 2 — через DB Browser for SQLite (GUI)
1. Открыть `database.db` (или создать новый).
2. Вкладка «Execute SQL» → вставить содержимое `schema.sql` → Run.
3. Затем `seed.sql` → Run.

### Вариант 3 — из Flutter (`sqflite`)
SQL-файлы можно положить в `assets/` и выполнять при инициализации БД.

## Сущности

| Таблица | Модуль | Назначение |
|---|---|---|
| `users` | Профиль | Пользователь |
| `categories` | Гардероб | Справочник категорий |
| `colors` | Гардероб | Справочник цветов (HEX) |
| `seasons` | Гардероб | Справочник сезонов |
| `clothing_items` | Гардероб | Вещи |
| `item_seasons` | Гардероб | Вещь ↔ сезон (M:N) |
| `outfits` | Образы | Образы |
| `outfit_items` | Образы | Образ ↔ вещь (M:N) |
| `wear_log` | Аналитика | Журнал надеваний |
| `wear_log_items` | Аналитика | Надевание ↔ вещь (M:N) |

## Связи и кардинальность

```
users        1 ──< * clothing_items
users        1 ──< * outfits
users        1 ──< * wear_log

categories   1 ──< * clothing_items
colors       1 ──< * clothing_items

clothing_items * ──< * seasons        (через item_seasons)
outfits        * ──< * clothing_items  (через outfit_items)
wear_log       * ──< * clothing_items  (через wear_log_items)
```

## Правила удаления (внешние ключи)

| Связь | Правило | Смысл |
|---|---|---|
| `outfit_items.item_id → clothing_items` | `CASCADE` | удалил вещь → убрана из всех образов |
| `outfit_items.outfit_id → outfits` | `CASCADE` | удалил образ → состав стирается, вещи остаются |
| `item_seasons.*` | `CASCADE` | удаление вещи/сезона чистит связи |
| `wear_log_items.*` | `CASCADE` | история чистится вместе с вещью |
| `clothing_items.user_id → users` | `CASCADE` | удалил пользователя → удаляется всё его |
| `clothing_items.category_id → categories` | `RESTRICT` | нельзя удалить категорию с вещами |
| `clothing_items.color_id → colors` | `SET NULL` | удалил цвет → у вещей цвет пустой |

## Аналитика: кэш и журнал

- `clothing_items.last_worn`, `wear_count` — **кэш** для быстрой сортировки «реже всего».
- `wear_log` + `wear_log_items` — **полная история** надеваний (для отчётов по датам).

При нажатии «Надеть сегодня»:
```sql
-- 1) запись в журнал
INSERT INTO wear_log(user_id, outfit_id, worn_at) VALUES (:uid, :oid, :now);
-- 2) состав надевания
INSERT INTO wear_log_items(wear_id, item_id)
  SELECT :wear_id, item_id FROM outfit_items WHERE outfit_id = :oid;
-- 3) обновление кэша у вещей
UPDATE clothing_items
   SET last_worn = :now, wear_count = wear_count + 1
 WHERE id IN (SELECT item_id FROM outfit_items WHERE outfit_id = :oid);
-- 4) обновление кэша у образа
UPDATE outfits SET last_worn = :now, wear_count = wear_count + 1 WHERE id = :oid;
```

## Типы данных

- ID — `TEXT` (UUID) для вещей/образов/пользователей; `INTEGER AUTOINCREMENT` для справочников и журнала.
- Даты — `TEXT` в формате ISO 8601 (`YYYY-MM-DD` / `YYYY-MM-DDTHH:MM:SS`), т.к. в SQLite нет отдельного типа даты.
- Деньги — `REAL` + `currency` (по умолчанию `RUB`).
- Сезоны — нормализованы через `item_seasons` (M:N), а не JSON.
