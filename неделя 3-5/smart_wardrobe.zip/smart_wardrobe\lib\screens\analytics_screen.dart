import 'dart:io';
import 'package:flutter/material.dart';
import '../models/clothing_item.dart';
import '../services/wardrobe_store.dart';
import '../utils/formatters.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAF8),
        title: const Text('Аналитика',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: ValueListenableBuilder<List<ClothingItem>>(
        valueListenable: WardrobeStore.instance.items,
        builder: (context, items, _) {
          final total = items.length;
          final neverWorn = items.where((it) => it.wearCount == 0).length;
          final percent = total == 0 ? 0 : (neverWorn * 100 / total).round();
          final sorted = [...items]..sort((a, b) {
              final la = a.lastWorn;
              final lb = b.lastWorn;
              if (la == null && lb == null) return a.name.compareTo(b.name);
              if (la == null) return -1;
              if (lb == null) return 1;
              return la.compareTo(lb);
            });
          final maxWear = items.fold<int>(
              0, (m, it) => it.wearCount > m ? it.wearCount : m);
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const Text('Реже всего носились',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _StatCard(value: '$total', label: 'вещей')),
                  const SizedBox(width: 10),
                  Expanded(child: _StatCard(value: '$neverWorn', label: 'ни разу')),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _StatCard(value: '$percent%', label: 'не носились')),
                ],
              ),
              const SizedBox(height: 16),
              if (items.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Center(
                    child: Text(
                      'Нет данных — добавьте вещи\nи отметьте образ как надетый.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF8A8694), height: 1.4),
                    ),
                  ),
                )
              else
                for (final it in sorted)
                  _RankRow(item: it, maxWear: maxWear),
            ],
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;
  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFECE9F2)),
      ),
      child: Column(
        children: [
          Text(value,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(label,
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontSize: 11, color: Color(0xFF8A8694))),
        ],
      ),
    );
  }
}

class _RankRow extends StatelessWidget {
  final ClothingItem item;
  final int maxWear;
  const _RankRow({required this.item, required this.maxWear});

  @override
  Widget build(BuildContext context) {
    final isZero = item.wearCount == 0;
    final ratio = maxWear == 0
        ? 0.0
        : (item.wearCount / maxWear).clamp(0.0, 1.0).toDouble();
    final subtitle = item.lastWorn == null
        ? 'ни разу'
        : 'последний раз ${formatDate(item.lastWorn!)}';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFECE9F2)),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F0FF),
              borderRadius: BorderRadius.circular(14),
            ),
            clipBehavior: Clip.antiAlias,
            child: item.imagePath != null
                ? Image.file(File(item.imagePath!), fit: BoxFit.cover)
                : const Icon(Icons.checkroom, color: Color(0xFF8A8694)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 13.5, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 11, color: Color(0xFF8A8694))),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: ratio,
                    minHeight: 5,
                    backgroundColor: const Color(0xFFECE9F2),
                    color: const Color(0xFF5B4BFF),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text('${item.wearCount} раз',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color:
                    isZero ? const Color(0xFFF0564A) : const Color(0xFF8A8694),
              )),
        ],
      ),
    );
  }
}
