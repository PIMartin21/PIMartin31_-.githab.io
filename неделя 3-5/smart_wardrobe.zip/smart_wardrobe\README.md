# SmartWardrobe

Приложение для управления гардеробом.

## Запуск (после установки Flutter SDK)
```
flutter pub get
flutter run
```
