import 'package:flutter/material.dart';
import '../models/clothing_item.dart';
import '../services/wardrobe_store.dart';
import '../widgets/clothing_card.dart';
import 'add_item_screen.dart';
import 'item_detail_screen.dart';

class WardrobeScreen extends StatefulWidget {
  const WardrobeScreen({super.key});

  @override
  State<WardrobeScreen> createState() => _WardrobeScreenState();
}

class _WardrobeScreenState extends State<WardrobeScreen> {
  String _category = 'Все';

  static const _categories = [
    'Все',
    'Верх',
    'Низ',
    'Обувь',
    'Верхняя одежда',
    'Аксессуары',
  ];

  List<ClothingItem> _filtered(List<ClothingItem> all) {
    if (_category == 'Все') return all;
    return all.where((e) => e.category == _category).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAF8),
        title:
            const Text('Гардероб', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
        ],
      ),
      body: ValueListenableBuilder<List<ClothingItem>>(
        valueListenable: WardrobeStore.instance.items,
        builder: (context, all, _) {
          final items = _filtered(all);
          return Column(
            children: [
              SizedBox(
                height: 48,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    for (final c in _categories)
                      _CategoryChip(
                        label: c,
                        active: _category == c,
                        onTap: () => setState(() => _category = c),
                      ),
                  ],
                ),
              ),
              if (_category == 'Все')
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const AddItemScreen(),
                        ),
                      ),
                      icon: const Icon(Icons.add),
                      label: const Text('Добавить вещь'),
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF5B4BFF),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                    ),
                  ),
                ),
              Expanded(
                child: items.isEmpty
                    ? const Center(
                        child: Text('Здесь пока нет вещей',
                            style: TextStyle(color: Color(0xFF8A8694))),
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.all(20),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 0.9,
                        ),
                        itemCount: items.length,
                        itemBuilder: (_, i) => ClothingCard(
                          item: items[i],
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  ItemDetailScreen(itemId: items[i].id),
                            ),
                          ),
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _CategoryChip({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? const Color(0xFF191720) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFECE9F2)),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
            color: active ? Colors.white : const Color(0xFF8A8694),
          ),
        ),
      ),
    );
  }
}
