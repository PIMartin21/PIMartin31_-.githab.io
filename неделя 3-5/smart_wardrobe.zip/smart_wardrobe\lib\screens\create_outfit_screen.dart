import 'dart:io';
import 'package:flutter/material.dart';
import '../models/clothing_item.dart';
import '../models/outfit.dart';
import '../services/wardrobe_store.dart';
import '../services/outfit_store.dart';

class CreateOutfitScreen extends StatefulWidget {
  /// Если передан — экран работает в режиме редактирования образа.
  final Outfit? initialOutfit;
  const CreateOutfitScreen({super.key, this.initialOutfit});

  @override
  State<CreateOutfitScreen> createState() => _CreateOutfitScreenState();
}

class _CreateOutfitScreenState extends State<CreateOutfitScreen> {
  final _nameController = TextEditingController();
  final Set<String> _selected = {};

  static const _categories = [
    'Верх',
    'Низ',
    'Обувь',
    'Верхняя одежда',
    'Аксессуары',
  ];

  bool get _isEditing => widget.initialOutfit != null;

  @override
  void initState() {
    super.initState();
    final outfit = widget.initialOutfit;
    if (outfit != null) {
      _nameController.text = outfit.name;
      final existingIds =
          WardrobeStore.instance.items.value.map((it) => it.id).toSet();
      _selected.addAll(outfit.itemIds.where(existingIds.contains));
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      _snack('Введите название образа');
      return;
    }
    if (_selected.isEmpty) {
      _snack('Выберите хотя бы одну вещь');
      return;
    }
    if (_isEditing) {
      OutfitStore.instance.update(Outfit(
        id: widget.initialOutfit!.id,
        name: name,
        itemIds: _selected.toList(),
        lastWorn: widget.initialOutfit!.lastWorn,
      ));
    } else {
      OutfitStore.instance.add(Outfit(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        name: name,
        itemIds: _selected.toList(),
      ));
    }
    Navigator.pop(context);
  }

  Future<void> _deleteOutfit() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Удалить образ?'),
        content: Text('«${widget.initialOutfit!.name}» будет удалён.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Удалить',
                style: TextStyle(color: Color(0xFFF0564A))),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      OutfitStore.instance.remove(widget.initialOutfit!.id);
      Navigator.pop(context);
    }
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAF8),
        title: Text(
          _isEditing ? 'Редактировать образ' : 'Новый образ',
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      body: ValueListenableBuilder<List<ClothingItem>>(
        valueListenable: WardrobeStore.instance.items,
        builder: (context, items, _) {
          if (items.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Сначала добавьте вещи в гардероб,\nпотом можно собрать образ.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF8A8694)),
                ),
              ),
            );
          }
          final selectedItems =
              items.where((it) => _selected.contains(it.id)).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const _FieldLabel('Название образа'),
              TextField(
                controller: _nameController,
                decoration: _inputDecoration('Например: Повседневный'),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Text('В образе',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF8A8694))),
                  const SizedBox(width: 6),
                  Text('(${selectedItems.length})',
                      style: const TextStyle(
                          fontSize: 12, color: Color(0xFF8A8694))),
                ],
              ),
              const SizedBox(height: 8),
              if (selectedItems.isEmpty)
                const Text(
                  'Пока пусто — выберите вещи ниже.\nНажмите ✕ у вещи, чтобы убрать её из образа.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF8A8694)),
                )
              else
                SizedBox(
                  height: 92,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: selectedItems.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, i) => _SelectedChip(
                      item: selectedItems[i],
                      onRemove: () =>
                          setState(() => _selected.remove(selectedItems[i].id)),
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              for (final cat in _categories)
                if (items.any((it) => it.category == cat)) ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 14, bottom: 8),
                    child: Text(
                      cat.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF8A8694),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (final it in items.where((it) => it.category == cat))
                        _SelectableItem(
                          item: it,
                          selected: _selected.contains(it.id),
                          onTap: () => setState(() {
                            if (_selected.contains(it.id)) {
                              _selected.remove(it.id);
                            } else {
                              _selected.add(it.id);
                            }
                          }),
                        ),
                    ],
                  ),
                ],
              const SizedBox(height: 28),
              FilledButton(
                onPressed: _save,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF5B4BFF),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(
                  _isEditing ? 'Сохранить изменения' : 'Сохранить образ',
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600),
                ),
              ),
              if (_isEditing) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _deleteOutfit,
                  icon: const Icon(Icons.delete_outline,
                      color: Color(0xFFF0564A)),
                  label: const Text('Удалить образ',
                      style: TextStyle(color: Color(0xFFF0564A))),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFF0564A)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF8A8694)),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFECE9F2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFFECE9F2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: Color(0xFF5B4BFF)),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Color(0xFF8A8694),
        ),
      ),
    );
  }
}

class _SelectedChip extends StatelessWidget {
  final ClothingItem item;
  final VoidCallback onRemove;
  const _SelectedChip({required this.item, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 88,
      child: Stack(
        children: [
          Column(
            children: [
              Container(
                height: 56,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F0FF),
                  borderRadius: BorderRadius.circular(12),
                ),
                clipBehavior: Clip.antiAlias,
                child: item.imagePath != null
                    ? Image.file(File(item.imagePath!), fit: BoxFit.cover)
                    : const Icon(Icons.checkroom, color: Color(0xFF8A8694)),
              ),
              const SizedBox(height: 4),
              Text(item.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 10.5, fontWeight: FontWeight.w600)),
            ],
          ),
          Positioned(
            top: -6,
            right: -6,
            child: GestureDetector(
              onTap: onRemove,
              child: Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(
                  color: Color(0xFFF0564A),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.close, size: 14, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SelectableItem extends StatelessWidget {
  final ClothingItem item;
  final bool selected;
  final VoidCallback onTap;
  const _SelectableItem({
    required this.item,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 88,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? const Color(0xFF5B4BFF) : const Color(0xFFECE9F2),
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Container(
              height: 56,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFF3F0FF),
                borderRadius: BorderRadius.circular(10),
              ),
              clipBehavior: Clip.antiAlias,
              child: item.imagePath != null
                  ? Image.file(File(item.imagePath!), fit: BoxFit.cover)
                  : const Icon(Icons.checkroom, color: Color(0xFF8A8694)),
            ),
            const SizedBox(height: 6),
            Text(
              item.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  fontSize: 10.5, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
