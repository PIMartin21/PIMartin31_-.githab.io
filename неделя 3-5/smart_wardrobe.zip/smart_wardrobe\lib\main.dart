import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'services/app_paths.dart';
import 'services/database_service.dart';
import 'services/wardrobe_store.dart';
import 'services/outfit_store.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppPaths.instance.init();
  await DatabaseService.instance.init();
  await WardrobeStore.instance.load();
  await OutfitStore.instance.load();
  runApp(const SmartWardrobeApp());
}

class SmartWardrobeApp extends StatelessWidget {
  const SmartWardrobeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartWardrobe',
      debugShowCheckedModeBanner: false,
      scrollBehavior: const _SlowScrollBehavior(),
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFAFAF8),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5B4BFF)),
      ),
      home: const HomeScreen(),
    );
  }
}

/// Плавная, медленная прокрутка без отскоков и без растягивания.
class _SlowScrollBehavior extends MaterialScrollBehavior {
  const _SlowScrollBehavior();

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const _SlowScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  }
}

class _SlowScrollPhysics extends ClampingScrollPhysics {
  const _SlowScrollPhysics({super.parent});

  @override
  _SlowScrollPhysics applyTo(ScrollPhysics? ancestor) {
    return _SlowScrollPhysics(parent: buildParent(ancestor));
  }

  @override
  double applyPhysicsToUserOffset(ScrollMetrics position, double offset) {
    return super.applyPhysicsToUserOffset(position, offset) * 0.75;
  }

  @override
  Simulation? createBallisticSimulation(
    ScrollMetrics position,
    double velocity,
  ) {
    if (position.outOfRange) {
      return super.createBallisticSimulation(position, velocity);
    }
    final tol = toleranceFor(position);
    if (velocity.abs() < tol.velocity) {
      return null;
    }
    return ClampingScrollSimulation(
      position: position.pixels,
      velocity: velocity,
      friction: 0.01,
      tolerance: tol,
    );
  }
}
