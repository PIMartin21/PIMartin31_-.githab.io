import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'app_paths.dart';

/// Работа с файлами фотографий: сохранение в папку приложения и удаление.
class ImageService {
  ImageService._();
  static final ImageService instance = ImageService._();

  /// Копирует выбранное фото в постоянную папку приложения.
  /// Возвращает АБСОЛЮТНЫЙ путь (его храним в памяти).
  Future<String> saveImage(XFile picked) async {
    final dir = AppPaths.instance.imagesDir;
    if (!await dir.exists()) await dir.create(recursive: true);
    final fileName = '${DateTime.now().microsecondsSinceEpoch}.jpg';
    final dest = p.join(dir.path, fileName);
    await File(picked.path).copy(dest);
    return dest;
  }

  /// Удаляет файл фото (по абсолютному пути). Безопасно вызывать с null.
  Future<void> deleteImage(String? absPath) async {
    if (absPath == null || absPath.isEmpty) return;
    final f = File(absPath);
    try {
      if (await f.exists()) await f.delete();
    } catch (_) {
      // игнорируем ошибки удаления
    }
  }
}
