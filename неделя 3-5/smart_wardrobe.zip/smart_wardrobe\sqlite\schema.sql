-- ============================================================
--  SmartWardrobe — схема базы данных (SQLite 3, UTF-8)
--  Внешние ключи в SQLite включаются отдельно:
--     PRAGMA foreign_keys = ON;
-- ============================================================

PRAGMA foreign_keys = ON;

-- ===== 1. Профиль =====
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,                          -- UUID
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  phone         TEXT,
  birth_date    TEXT,                                      -- 'YYYY-MM-DD'
  gender        TEXT CHECK (gender IN ('male','female','other')),
  city          TEXT,
  style         TEXT,                                      -- любимый стиль
  size          TEXT,
  avatar_path   TEXT,
  password_hash TEXT,                                      -- NULL при OAuth
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ===== 2. Справочники =====
CREATE TABLE IF NOT EXISTS categories (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,                               -- Верх, Низ, ...
  sort INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS colors (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  hex  TEXT                                                -- '#FFFFFF'
);

CREATE TABLE IF NOT EXISTS seasons (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE                                -- Лето, Весна, ...
);

-- ===== 3. Гардероб =====
CREATE TABLE IF NOT EXISTS clothing_items (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL,
  category_id INTEGER NOT NULL,
  color_id    INTEGER,
  name        TEXT NOT NULL,
  description TEXT,
  size        TEXT,
  image_path  TEXT,
  price       REAL CHECK (price IS NULL OR price >= 0),
  currency    TEXT NOT NULL DEFAULT 'RUB',
  last_worn   TEXT,                                        -- ISO-дата последнего надевания
  wear_count  INTEGER NOT NULL DEFAULT 0 CHECK (wear_count >= 0),
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  FOREIGN KEY (color_id)    REFERENCES colors(id)     ON DELETE SET NULL
);

-- связь вещь ↔ сезон (M:N)
CREATE TABLE IF NOT EXISTS item_seasons (
  item_id   TEXT    NOT NULL,
  season_id INTEGER NOT NULL,
  PRIMARY KEY (item_id, season_id),
  FOREIGN KEY (item_id)   REFERENCES clothing_items(id) ON DELETE CASCADE,
  FOREIGN KEY (season_id) REFERENCES seasons(id)        ON DELETE CASCADE
);

-- ===== 4. Образы =====
CREATE TABLE IF NOT EXISTS outfits (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL,
  name        TEXT NOT NULL,
  description TEXT,
  cover_image TEXT,
  last_worn   TEXT,
  wear_count  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- связь образ ↔ вещь (M:N)
CREATE TABLE IF NOT EXISTS outfit_items (
  outfit_id TEXT    NOT NULL,
  item_id   TEXT    NOT NULL,
  position  INTEGER NOT NULL DEFAULT 0,                    -- порядок в образе
  PRIMARY KEY (outfit_id, item_id),
  FOREIGN KEY (outfit_id) REFERENCES outfits(id)        ON DELETE CASCADE,
  FOREIGN KEY (item_id)   REFERENCES clothing_items(id) ON DELETE CASCADE
);

-- ===== 5. Аналитика: журнал надеваний =====
CREATE TABLE IF NOT EXISTS wear_log (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id   TEXT NOT NULL,
  outfit_id TEXT,                                          -- NULL, если надели отдельную вещь
  worn_at   TEXT NOT NULL,                                 -- ISO-дата/время
  note      TEXT,
  FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
  FOREIGN KEY (outfit_id) REFERENCES outfits(id) ON DELETE SET NULL
);

-- какие вещи входили в каждое надевание (M:N)
CREATE TABLE IF NOT EXISTS wear_log_items (
  wear_id INTEGER NOT NULL,
  item_id TEXT    NOT NULL,
  PRIMARY KEY (wear_id, item_id),
  FOREIGN KEY (wear_id) REFERENCES wear_log(id)       ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES clothing_items(id) ON DELETE CASCADE
);

-- ===== 6. Индексы =====
CREATE INDEX IF NOT EXISTS idx_items_user         ON clothing_items(user_id);
CREATE INDEX IF NOT EXISTS idx_items_category     ON clothing_items(category_id);
CREATE INDEX IF NOT EXISTS idx_items_last_worn    ON clothing_items(last_worn);
CREATE INDEX IF NOT EXISTS idx_outfits_user       ON outfits(user_id);
CREATE INDEX IF NOT EXISTS idx_outfit_items_item  ON outfit_items(item_id);
CREATE INDEX IF NOT EXISTS idx_wearlog_user_date  ON wear_log(user_id, worn_at);
CREATE INDEX IF NOT EXISTS idx_wearlog_items_item ON wear_log_items(item_id);
