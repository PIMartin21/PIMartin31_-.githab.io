package com.example.smart_wardrobe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
