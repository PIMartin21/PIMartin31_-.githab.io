import 'package:flutter/foundation.dart';
import '../models/clothing_item.dart';
import 'database_service.dart';
import 'image_service.dart';
import 'outfit_store.dart';

/// Хранилище вещей. Держит список в памяти для UI и синхронизирует с БД.
class WardrobeStore {
  WardrobeStore._();
  static final WardrobeStore instance = WardrobeStore._();

  final ValueNotifier<List<ClothingItem>> items =
      ValueNotifier<List<ClothingItem>>(const <ClothingItem>[]);

  /// Загрузить вещи из БД (при старте).
  Future<void> load() async {
    items.value = await DatabaseService.instance.getItems();
  }

  void add(ClothingItem item) {
    items.value = [...items.value, item];
    DatabaseService.instance.insertItem(item);
  }

  void update(ClothingItem item) {
    items.value = [
      for (final it in items.value)
        if (it.id == item.id) item else it,
    ];
    DatabaseService.instance.updateItem(item);
  }

  void remove(String id) {
    final match = items.value.where((it) => it.id == id).toList();
    if (match.isNotEmpty) {
      ImageService.instance.deleteImage(match.first.imagePath);
    }
    items.value = items.value.where((it) => it.id != id).toList();
    DatabaseService.instance.deleteItem(id);

    // Убираем вещь из всех образов; если образ опустел — удаляем его.
    OutfitStore.instance.handleItemRemoved(id);
  }

  /// Отметить вещи как надетые (обновляет дату и счётчик).
  void markWornMany(List<String> ids, DateTime when) {
    final set = ids.toSet();
    items.value = [
      for (final it in items.value)
        set.contains(it.id)
            ? it.copyWith(lastWorn: when, wearCount: it.wearCount + 1)
            : it,
    ];
    DatabaseService.instance.markWorn(ids, when);
  }
}
