class ClothingItem {
  final String id;
  final String name;
  final String description;
  final String category;
  final String color;
  final List<String> season;
  final String? imagePath;
  final double? price;

  /// Когда вещь последний раз надевали (через образ).
  final DateTime? lastWorn;

  /// Сколько раз вещь надевали.
  final int wearCount;

  const ClothingItem({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.color,
    required this.season,
    this.imagePath,
    this.price,
    this.lastWorn,
    this.wearCount = 0,
  });

  ClothingItem copyWith({
    DateTime? lastWorn,
    int? wearCount,
  }) {
    return ClothingItem(
      id: id,
      name: name,
      description: description,
      category: category,
      color: color,
      season: season,
      imagePath: imagePath,
      price: price,
      lastWorn: lastWorn ?? this.lastWorn,
      wearCount: wearCount ?? this.wearCount,
    );
  }
}
