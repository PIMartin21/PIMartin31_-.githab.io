import 'package:flutter/foundation.dart';
import '../models/outfit.dart';
import 'database_service.dart';
import 'wardrobe_store.dart';

/// Хранилище образов. Держит список в памяти и синхронизирует с БД.
class OutfitStore {
  OutfitStore._();
  static final OutfitStore instance = OutfitStore._();

  final ValueNotifier<List<Outfit>> outfits =
      ValueNotifier<List<Outfit>>(const <Outfit>[]);

  Future<void> load() async {
    final loaded = await DatabaseService.instance.getOutfits();
    // Чистим «осиротевшие» образы, в которых не осталось вещей.
    final valid = <Outfit>[];
    for (final o in loaded) {
      if (o.itemIds.isEmpty) {
        DatabaseService.instance.deleteOutfit(o.id);
      } else {
        valid.add(o);
      }
    }
    outfits.value = valid;
  }

  void add(Outfit outfit) {
    outfits.value = [...outfits.value, outfit];
    DatabaseService.instance.insertOutfit(outfit);
  }

  void update(Outfit outfit) {
    outfits.value = [
      for (final o in outfits.value)
        if (o.id == outfit.id) outfit else o,
    ];
    DatabaseService.instance.updateOutfit(outfit);
  }

  void remove(String id) {
    outfits.value = outfits.value.where((o) => o.id != id).toList();
    DatabaseService.instance.deleteOutfit(id);
  }

  /// Надели образ: обновляем дату образа и всех его вещей.
  void wear(String id, DateTime when) {
    final match = outfits.value.where((o) => o.id == id).toList();
    if (match.isEmpty) return;
    final current = match.first;

    outfits.value = [
      for (final o in outfits.value)
        if (o.id == id) o.copyWith(lastWorn: when) else o,
    ];
    WardrobeStore.instance.markWornMany(current.itemIds, when);
    DatabaseService.instance.recordWearOutfit(current, when);
  }

  /// Вызывается при удалении вещи из гардероба.
  /// Убирает вещь из всех образов; если образ опустел — удаляет образ.
  void handleItemRemoved(String itemId) {
    final updated = <Outfit>[];
    for (final o in outfits.value) {
      if (!o.itemIds.contains(itemId)) {
        updated.add(o);
        continue;
      }
      final newIds = o.itemIds.where((id) => id != itemId).toList();
      if (newIds.isEmpty) {
        // В образе не осталось вещей — удаляем сам образ.
        DatabaseService.instance.deleteOutfit(o.id);
      } else {
        // Образ остаётся, но без удалённой вещи.
        final newOutfit = Outfit(
          id: o.id,
          name: o.name,
          itemIds: newIds,
          lastWorn: o.lastWorn,
        );
        updated.add(newOutfit);
        DatabaseService.instance.updateOutfit(newOutfit);
      }
    }
    outfits.value = updated;
  }
}
