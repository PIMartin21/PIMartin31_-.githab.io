class Outfit {
  final String id;
  final String name;
  final List<String> itemIds;
  final DateTime? lastWorn;

  const Outfit({
    required this.id,
    required this.name,
    required this.itemIds,
    this.lastWorn,
  });

  Outfit copyWith({DateTime? lastWorn}) {
    return Outfit(
      id: id,
      name: name,
      itemIds: itemIds,
      lastWorn: lastWorn ?? this.lastWorn,
    );
  }
}
