import 'dart:io';
import 'package:flutter/material.dart';
import '../models/clothing_item.dart';
import '../services/wardrobe_store.dart';
import '../utils/app_colors.dart';
import '../utils/formatters.dart';
import 'add_item_screen.dart';

/// Экран просмотра вещи. Следит за хранилищем,
/// поэтому после редактирования сразу показывает новые данные.
class ItemDetailScreen extends StatelessWidget {
  final String itemId;
  const ItemDetailScreen({super.key, required this.itemId});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<ClothingItem>>(
      valueListenable: WardrobeStore.instance.items,
      builder: (context, all, _) {
        final current = all.where((e) => e.id == itemId).toList();
        if (current.isEmpty) {
          return Scaffold(
            appBar: AppBar(backgroundColor: const Color(0xFFFAFAF8)),
            body: const Center(child: Text('Вещь не найдена')),
          );
        }
        final item = current.first;
        return Scaffold(
          appBar: AppBar(
            backgroundColor: const Color(0xFFFAFAF8),
            title: const Text('Просмотр вещи',
                style: TextStyle(fontWeight: FontWeight.w700)),
            actions: [
              IconButton(
                tooltip: 'Редактировать',
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddItemScreen(initialItem: item),
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Удалить',
                icon: const Icon(Icons.delete_outline,
                    color: Color(0xFFF0564A)),
                onPressed: () => _delete(context, item),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              if (item.imagePath != null)
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.file(
                    File(item.imagePath!),
                    height: 280,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _noPhoto(),
                  ),
                )
              else
                _noPhoto(),
              const SizedBox(height: 18),
              Text(item.name,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(item.category,
                  style: const TextStyle(
                      fontSize: 13, color: Color(0xFF8A8694))),
              const SizedBox(height: 16),
              if (item.description.isNotEmpty) ...[
                const Text('Описание',
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF8A8694))),
                const SizedBox(height: 6),
                Text(item.description,
                    style: const TextStyle(fontSize: 14, height: 1.4)),
                const SizedBox(height: 18),
              ],
              if (item.price != null)
                _InfoRow(
                  label: 'Стоимость',
                  value: formatMoney(item.price!),
                ),
              _InfoRow(
                label: 'Цвет',
                value: item.color,
                swatch: colorForName(item.color),
              ),
              _InfoRow(
                label: 'Сезон',
                value: item.season.join(', '),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _noPhoto() {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        color: const Color(0xFFF3F0FF),
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Center(
        child: Icon(Icons.image_outlined, size: 48, color: Color(0xFF8A8694)),
      ),
    );
  }

  Future<void> _delete(BuildContext context, ClothingItem item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Удалить вещь?'),
        content: Text('«${item.name}» будет удалена из гардероба.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Удалить',
                style: TextStyle(color: Color(0xFFF0564A))),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      WardrobeStore.instance.remove(item.id);
      Navigator.pop(context);
    }
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? swatch;
  const _InfoRow({required this.label, required this.value, this.swatch});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFECE9F2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: const TextStyle(fontSize: 13, color: Color(0xFF8A8694))),
          ),
          if (swatch != null) ...[
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                color: swatch,
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFECE9F2)),
              ),
            ),
            const SizedBox(width: 6),
          ],
          Text(value,
              style: const TextStyle(
                  fontSize: 13.5, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
