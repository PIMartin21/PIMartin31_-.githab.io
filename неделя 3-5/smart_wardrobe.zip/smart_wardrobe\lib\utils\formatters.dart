/// Красиво форматирует стоимость: 1500 -> «1 500 ₽».
String formatMoney(double value) {
  final s = value.toStringAsFixed(0);
  final reg = RegExp(r'(\d)(?=(\d{3})+$)');
  return '${s.replaceAllMapped(reg, (m) => '${m[1]} ')} ₽';
}

/// Форматирует дату как дд.мм.гггг.
String formatDate(DateTime d) {
  final dd = d.day.toString().padLeft(2, '0');
  final mm = d.month.toString().padLeft(2, '0');
  return '$dd.$mm.${d.year}';
}
