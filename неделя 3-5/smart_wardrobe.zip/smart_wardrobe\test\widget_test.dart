﻿import 'package:flutter_test/flutter_test.dart';

import 'package:smart_wardrobe/main.dart';

void main() {
  testWidgets('SmartWardrobe app builds', (WidgetTester tester) async {
    await tester.pumpWidget(const SmartWardrobeApp());
  });
}
