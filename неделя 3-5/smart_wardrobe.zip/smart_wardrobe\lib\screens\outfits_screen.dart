import 'dart:io';
import 'package:flutter/material.dart';
import '../models/clothing_item.dart';
import '../models/outfit.dart';
import '../services/outfit_store.dart';
import '../services/wardrobe_store.dart';
import '../utils/formatters.dart';
import 'create_outfit_screen.dart';

class OutfitsScreen extends StatelessWidget {
  const OutfitsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAFAF8),
        title:
            const Text('Образы', style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: ValueListenableBuilder<List<Outfit>>(
        valueListenable: OutfitStore.instance.outfits,
        builder: (context, outfits, _) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const CreateOutfitScreen()),
                ),
                icon: const Icon(Icons.add),
                label: const Text('Создать образ'),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF5B4BFF),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (outfits.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Center(
                    child: Text(
                      'Пока нет образов.\nСоберите образ из вещей —\nи отмечайте его одним нажатием.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF8A8694), height: 1.4),
                    ),
                  ),
                )
              else
                for (final o in outfits) _OutfitCard(outfit: o),
            ],
          );
        },
      ),
    );
  }
}

class _OutfitCard extends StatelessWidget {
  final Outfit outfit;
  const _OutfitCard({required this.outfit});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFECE9F2)),
      ),
      child: ValueListenableBuilder<List<ClothingItem>>(
        valueListenable: WardrobeStore.instance.items,
        builder: (context, items, _) {
          final outfitItems = items
              .where((it) => outfit.itemIds.contains(it.id))
              .toList();
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  for (var i = 0; i < outfitItems.length && i < 4; i++) ...[
                    if (i > 0) const SizedBox(width: 8),
                    _thumb(outfitItems[i]),
                  ],
                  const Spacer(),
                  IconButton(
                    tooltip: 'Редактировать образ',
                    icon: const Icon(Icons.edit_outlined, size: 20),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            CreateOutfitScreen(initialOutfit: outfit),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(outfit.name,
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 3),
              Text(
                _subtitle(outfitItems.length),
                style: const TextStyle(
                    fontSize: 11.5, color: Color(0xFF8A8694)),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    OutfitStore.instance.wear(outfit.id, DateTime.now());
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                            'Образ «${outfit.name}» надет — вещи отмечены'),
                      ),
                    );
                  },
                  icon: const Icon(Icons.check, size: 18),
                  label: const Text('Надеть сегодня'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF5B4BFF),
                    side: const BorderSide(color: Color(0xFF5B4BFF)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _thumb(ClothingItem item) {
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        color: const Color(0xFFF3F0FF),
        borderRadius: BorderRadius.circular(12),
      ),
      clipBehavior: Clip.antiAlias,
      child: item.imagePath != null
          ? Image.file(File(item.imagePath!), fit: BoxFit.cover)
          : const Icon(Icons.checkroom, color: Color(0xFF8A8694)),
    );
  }

  String _subtitle(int count) {
    if (outfit.lastWorn == null) return '$count вещей · ещё не надевали';
    return '$count вещей · последний раз ${formatDate(outfit.lastWorn!)}';
  }
}
